CREATE DATABASE IF NOT EXISTS task_service_db;
USE task_service_db;

CREATE TABLE IF NOT EXISTS tasks (
                                     task_id BIGINT NOT NULL AUTO_INCREMENT,
                                     user_id BIGINT NOT NULL,
                                     title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    task_status VARCHAR(32) NOT NULL DEFAULT 'TODO',
    task_priority VARCHAR(32) NOT NULL DEFAULT 'MEDIUM',
    task_day DATE NOT NULL,
    startDate TIME NOT NULL,
    endDate TIME NOT NULL,
    weekly BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (task_id),
    CONSTRAINT chk_task_status
    CHECK (task_status IN ('TODO', 'IN_PROGRESS', 'DONE', 'BLOCKED', 'CANCELED')),
    CONSTRAINT chk_task_priority
    CHECK (task_priority IN ('LOW', 'MEDIUM', 'HIGH', 'URGENT'))
    );

CREATE TABLE IF NOT EXISTS sub_tasks (
                                         subtask_id BIGINT NOT NULL AUTO_INCREMENT,
                                         task_id BIGINT NOT NULL,
                                         subtask_title VARCHAR(50) NOT NULL,
    subtask_completed BOOLEAN NOT NULL DEFAULT FALSE,
    completedDate DATE,
    PRIMARY KEY (subtask_id),
    CONSTRAINT fk_subtask_task
    FOREIGN KEY (task_id)
    REFERENCES tasks(task_id)
    ON DELETE CASCADE
    );