package com.example.Task.Service.business.Impl.tasksImpl;

import com.example.Task.Service.business.ICreateTask;
import com.example.Task.Service.domain.tasksRequestsResponse.CreateTaskRequest;
import com.example.Task.Service.domain.tasksRequestsResponse.CreateTaskResponse;
import com.example.Task.Service.domain.TaskPriority;
import com.example.Task.Service.domain.TaskStatus;
import com.example.Task.Service.repository.TasksRepository;
import com.example.Task.Service.repository.TasksEntity;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;


@AllArgsConstructor
@Service
public class CreateTaskImpl implements ICreateTask {
    private final TasksRepository tasksRepository;

    @Transactional
    @Override
    public CreateTaskResponse createTask(CreateTaskRequest request) {
        if(request.getTask_end_date().isBefore(request.getTask_start_date())){
            throw new IllegalArgumentException("Task end date must be after start date!");

        }
        TasksEntity tasksEntity = saveTask(request);

        return CreateTaskResponse.builder().taskId(tasksEntity.getTask_id()).build();

    }

    private TasksEntity saveTask(CreateTaskRequest request) {
        TasksEntity tasksEntity = TasksEntity.builder()
                .task_priority(TaskPriority.MEDIUM)
                .task_description(request.getDescription())
                .task_title(request.getTitle())
                .task_status(TaskStatus.TODO)
                .user_id(request.getUserId())
                .task_start_date(request.getTask_start_date())
                .task_end_date(request.getTask_end_date())
                .build();

        return tasksRepository.save(tasksEntity);
    }

}
