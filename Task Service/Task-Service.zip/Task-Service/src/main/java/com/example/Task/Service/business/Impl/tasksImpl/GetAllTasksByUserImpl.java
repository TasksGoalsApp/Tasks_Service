package com.example.Task.Service.business.Impl.tasksImpl;

public class GetAllTasksByUserImpl {
}
