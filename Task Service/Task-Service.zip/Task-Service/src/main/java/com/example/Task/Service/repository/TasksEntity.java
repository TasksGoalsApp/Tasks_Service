package com.example.Task.Service.repository;

import com.example.Task.Service.domain.TaskPriority;
import com.example.Task.Service.domain.TaskStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicUpdate;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@DynamicUpdate
@Table(name = "tasks")
public class TasksEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_id")
    private long task_id;

    @Column(name = "user_id")
    private long user_id;

    @NotBlank
    @Column(name = "title")
    private String task_title;

    @NotBlank
    @Column(name = "description")
    private String task_description;

    @Enumerated(EnumType.STRING)
    @Column(name = "task_status", nullable = false, length = 32)
    private TaskStatus task_status = TaskStatus.TODO;

    @Enumerated(EnumType.STRING)
    @Column(name = "task_priority", nullable = false, length = 32)
    private TaskPriority task_priority;

    @NotNull
    @Column(nullable = false)
    private LocalDate task_day;

    @Column(name = "startDate")
    private LocalDate start_date;
    @Column(name = "endDate")
    private LocalDate end_date;
    @Column(name = "start_time")
    private LocalTime start_time;
    @Column(name = "end_time")
    private LocalTime end_time;

    @Column(nullable = false)
    private boolean weekly;

    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SubTasksEntity> subTasksList = new ArrayList<>();

}
