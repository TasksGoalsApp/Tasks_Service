package com.example.Task.Service.domain.tasksRequestsResponse;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateTaskRequest {

    @NotBlank
    private String title;
    @NotBlank
    private String description;
    @NotNull
    private long userId;
    @NotNull
    private LocalDate task_start_date;
    @NotNull
    private LocalDate task_end_date;


}
