package com.example.Task.Service.business.Impl.tasksImpl;

import com.example.Task.Service.business.IUpdateTask;
import com.example.Task.Service.business.Impl.ResourceNotFoundException;
import com.example.Task.Service.domain.tasksRequestsResponse.UpdateTaskRequest;
import com.example.Task.Service.domain.tasksRequestsResponse.UpdateTaskResponse;
import com.example.Task.Service.repository.TasksEntity;
import com.example.Task.Service.repository.TasksRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class UpdateTaskImpl implements IUpdateTask {
    private final TasksRepository tasksRepository;

    @Override
    public UpdateTaskResponse updateTask(UpdateTaskRequest updateTaskRequest) {
        if(updateTaskRequest.getTask_end_date().isBefore(updateTaskRequest.getTask_start_date())){
            throw new IllegalArgumentException("Task end date must be after start date!");
        }
        TasksEntity tasksEntity = tasksRepository.findById(updateTaskRequest.getTaskId())
                .orElseThrow(() -> new ResourceNotFoundException("Task not found!"));

        tasksEntity.setTask_end_date(updateTaskRequest.getTask_end_date());
        tasksEntity.setTask_start_date(updateTaskRequest.getTask_start_date());
        tasksEntity.setTask_description(updateTaskRequest.getTask_description());
        tasksEntity.setTask_status(updateTaskRequest.getTask_status());
        tasksEntity.setTask_priority(updateTaskRequest.getTask_priority());
        tasksEntity.setTask_title(updateTaskRequest.getTask_title());
        TasksEntity savedTask = tasksRepository.save(tasksEntity);

        return UpdateTaskResponse.builder()
                .task_id(savedTask.getTask_id())
                .task_description(savedTask.getTask_description())
                .task_end_date(savedTask.getTask_end_date())
                .task_start_date(savedTask.getTask_start_date())
                .task_status(savedTask.getTask_status())
                .task_priority(savedTask.getTask_priority())
                .task_title(savedTask.getTask_title())
                .user_id(savedTask.getUser_id())
                .build();
    }
}
